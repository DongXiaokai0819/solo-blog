title: Java 类加载过程 与 类加载器（双亲委派模型）
date: '2019-11-08 16:41:59'
updated: '2019-11-08 16:42:31'
tags: [Java, JVM]
permalink: /articles/2019/11/08/1573202517793.html
---
# JVM执行子系统

## 二、虚拟机类加载机制

### 类加载过程
> 类从被加载到虚拟机内存中开始，到卸载出内存为止，它的整个生命周期包括：加载（Loading）、验证（Verification）、准备（Preparation）、解析（Resolution）、初始化（Initialization）、使用（Using）和卸载（Unloading）7个阶段。其中验证、准备、解析3个部分统称为连接（Linking）。

7个阶段发生顺序如下图所示：

![类加载过程.jpg](https://img.hacpai.com/file/2019/11/类加载过程-74bf8748.jpg)



#### 1、加载
**“加载”是“类加载”过程的一个阶段。**

类加载过程的第一步，主要完成下面3件事情：
1. 通过全类名获取定义此类的二进制字节流。
2. 将字节流所代表的静态存储结构转换为方法区的运行时数据结构。
3. 在内存中生成一个代表该类的 Class 对象,作为方法区这些数据的访问入口。

&nbsp;&nbsp;&nbsp;&nbsp;虚拟机规范多上面这3点并不具体，因此是非常灵活的。比如："通过全类名获取定义此类的二进制字节流" 并没有指明具体从哪里获取、怎样获取。比如：比较常见的就是从 ZIP 包中读取（日后出现的JAR、EAR、WAR格式的基础）、其他文件生成（典型应用就是JSP）等等。

&nbsp;&nbsp;&nbsp;&nbsp;一个非数组类的加载阶段（加载阶段获取类的二进制字节流的动作）是可控性最强的阶段，这一步我们可以去完成还可以自定义类加载器去控制字节流的获取方式（重写一个类加载器的 loadClass() 方法）。数组类型不通过类加载器创建，它由 Java 虚拟机直接创建。

> 加载阶段完成后，虚拟机外部的二进制字节流就按照虚拟机所需的格式存储在方法区之中，方法区中的数据存储格式由虚拟机实现自行定义，虚拟机规范未规定此区域的具体数据结构。然后在内存中实例化一个java.lang.Class类的对象（就HotSpot而言，Class对象存放在方法区中）。
> 加载阶段和连接阶段的部分内容是交叉进行的，加载阶段尚未结束，连接阶段可能就已经开始了。

#### 2、验证

&nbsp;&nbsp;&nbsp;&nbsp;是连接阶段的第一步，这一阶段的目的是为了确保Class文件的字节流中包含的信息符合当前虚拟机的要求，并且不会危害虚拟机自身的安全。但从整体上看，验证阶段大致上会完成下面4个阶段的检验动作：文件格式验证、元数据验证、字节码验证、符号引用验证。

![验证阶段.png](https://img.hacpai.com/file/2019/11/验证阶段-4885078e.png)


#### 3、准备

&nbsp;&nbsp;&nbsp;&nbsp;准备阶段是正式为类变量分配内存并设置类变量初始值的阶段，这些内存都将在方法区中分配。对于该阶段有以下几点需要注意：

1. 这时候进行内存分配的仅包括类变量（static），而不包括实例变量，实例变量会在对象实例化时随着对象一块分配在 Java 堆中。
2. 这里所设置的初始值"通常情况"下是数据类型默认的零值（如0、0L、null、false等），比如我们定义了public static int value=111 ，那么 value 变量在准备阶段的初始值就是 0 而不是111（初始化阶段才会赋值）。

![基本数据类型的零值.png](https://img.hacpai.com/file/2019/11/基本数据类型的零值-7895e23f.png)



特殊情况：如果类字段的字段属性表中存在ConstantValue属性（static final）那么在准备阶段变量就会被赋值。

如`public static final int value = 123;`
在编译时javac将会为value生成ConstantValue属性，在准备阶段虚拟机就会根据ConstantValue的设置将value赋值为123。

#### 4、解析

> 解析阶段是虚拟机将常量池内的符号引用替换为直接引用的过程。

&nbsp;&nbsp;&nbsp;&nbsp;解析动作主要针对类或接口、字段、类方法、接口方法、方法类型、方法句柄和调用限定符7类符号引用进行。

解析阶段中所说地直接引用与符号引用有什么关联？
+ 符号引用就是一组符号来描述所引用的目标，符号可以是任何字面量，只要使用时能无歧义地定位到目标即可。
+ 直接引用就是直接指向目标的指针、相对偏移量或一个间接定位到目标的句柄。

&nbsp;&nbsp;&nbsp;&nbsp;在程序实际运行时，只有符号引用是不够的，举个例子：在程序执行方法时，系统需要明确知道这个方法所在的位置。Java 虚拟机为每个类都准备了一张方法表来存放类中所有的方法。当需要调用一个类的方法的时候，只要知道这个方法在方发表中的偏移量就可以直接调用该方法了。通过解析操作符号引用就可以直接转变为目标方法在类中方法表的位置，从而使得方法可以被调用。

&nbsp;&nbsp;&nbsp;&nbsp;综上，解析阶段是虚拟机将常量池内的符号引用替换为直接引用的过程，也就是得到类或者字段、方法在内存中的指针或者偏移量。

#### 5、初始化

##### 5.1 什么时候对类进行“初始化”？

对于初始化阶段，虚拟机规范则是严格规定了**有且只有**5种情况必须立即对类进行“初始化”（而加载、验证、准备自然需要在此之前开始）：
1. 遇到new、getstatic、putstatic或invokestatic这4条字节码指令时，如果类没有进行过初始化，则需要先触发其初始化。生成这4条指令的最常见的Java代码场景是：使用new关键字实例化对象的时候、读取或设置一个类的静态字段（被final修饰、已在编译期把结果放入常量池的静态字段除外）的时候，以及调用一个类的静态方法的时候。
2. 使用java.lang.reflect包的方法对类进行反射调用的时候，如果类没有进行过初始化，则需要先触发其初始化。
3. 当初始化一个类的时候，如果发现其父类还没有进行过初始化，则需要先触发其父类的初始化。
4. 当虚拟机启动时，用户需要指定一个要执行的主类（包含main（）方法的那个类），虚拟机会先初始化这个主类。
5. 当使用JDK 1.7的动态语言支持时，如果一个java.lang.invoke.MethodHandle实例最后的解析结果REF_getStatic、REF_putStatic、REF_invokeStatic的方法句柄，并且这个方法句柄所对应的类没有进行过初始化，则需要先触发其初始化。

接口的初始化过程：

> 一个接口在初始化时，并不要求其父接口全部都完成了初始化，只有在真正使用到父接口的时候才会初始化。

##### 5.2 被动引用示例

###### a. 子类引用父类的静态字段

&nbsp;&nbsp;&nbsp;&nbsp;子类引用父类的静态字段时，不会导致**子类**的初始化。

示例代码：
```
public class SuperClass {
    static {
        System.out.println("SuperClass init!");
    }
    public static int value = 123;
}

public class SubClass extends SuperClass {
    static {
        System.out.println("SubClass init!");
    }
}

public class NotInitialization {
    public static void main(String[] args) {
        System.out.println(SubClass.value);
    }
}
```

上述代码只会输出“SuperClass init!”，而不会输出“SubClass”。

> 对于静态字段，只有直接定义这个字段的类才会被初始化，因此通过其子类来引用父类中定义的静态字段，只会触发父类的初始化而不会触发子类的初始化。


###### b. 通过数组定义来引用类

&nbsp;&nbsp;&nbsp;&nbsp;通过数组定义来引用类，不会触发此类的初始化
```
public class NotInitialization {
    public static void main(String[] args) {
        SuperClass[] sca = new SuperClass[10];
    }
}
```

上述代码运行过后，并不会输出“SuperClass init!”， 说明并没有触发SuperClass类的初始化

###### c. 引用常量

&nbsp;&nbsp;&nbsp;&nbsp;常量在编译阶段会存入调用类的常量池中，本质上并没有直接引用到定义常量的累，因此不会触发定义常量的类的初始化。

```
public class ConstClass {
    static {
        System.out.println("ConstClass init!");
    }
    public static final String HELLOWORLD = "hello world!";
}

public class NotInitialization {
    public static void main(String[] args) {
        System.out.println(ConstClass.HELLOWORLD);
    }
}
```

上述代码执行后不会输出“ConstClass init！”

> A类中定义的常量，在编译阶段通过常量传播优化，已经将常量存储到了调用该类A常量的 类B的常量池中了，以后类B调用该常量都是调用的自己的常量池中的常量。也就是说类A和类B，虽然B调用了A的常量，但是这俩个类在编译成Class之后就不存在任何联系了。

##### 5.3 ＜clinit＞（）
> &nbsp;&nbsp;&nbsp;&nbsp;类初始化阶段是类加载过程的最后一步，前面的类加载过程中，除了在加载阶段用户应用程序可以通过自定义类加载器参与之外，其余动作完全由虚拟机主导和控制。到了初始化阶段，才真正开始执行类中定义的Java程序代码。
> &nbsp;&nbsp;&nbsp;&nbsp;在准备阶段，变量已经赋过一次系统要求的初始值，而在初始化阶段，则根据程序员通过程序制定的主观计划去初始化类变量和其他资源，或者可以从另外一个角度来表达：初始化阶段是执行类构造器＜clinit＞（）方法的过程。

&nbsp;&nbsp;&nbsp;&nbsp;＜clinit＞（）方法是由编译器自动收集类中的所有类变量的赋值动作和静态语句块（static{}块）中的语句合并产生的，编译器收集的顺序是由语句在源文件中出现的顺序所决定的。**静态语句块中只能访问到定义在静态语句块之前的变量，定义在它之后的变量，在前面的静态语句块可以赋值，但是不能访问。**

![非法向前引用.png](https://img.hacpai.com/file/2019/11/非法向前引用-df4daf24.png)


&nbsp;&nbsp;&nbsp;&nbsp;＜clinit＞（）方法与类的 构造函数（实例构造器<init>()方法）不同，它不需要显示地调用父类构造器，虚拟机会保证在子类的＜clinit＞（）方法执行之前，父类的＜clinit＞（）方法已经执行完毕。所以**在虚拟机中第一个被执行的＜clinit＞（）方法的类肯定是java.lang.Object**。

&nbsp;&nbsp;&nbsp;&nbsp;由于父类的＜clinit＞（）方法先执行，也就意味着父类中定义的静态语句块要优先于子类中的变脸赋值操作。

```
public class Parent {
    public static int A = 1;

    static {
        A = 2;
    }

    static class Sub extends Parent{
        public static int B = A;
    }

    public static void main(String[] args) {
        System.out.println(Sub.B);
    }
}
```
所以上述代码的运行结果应该是 `2` 而不是 `1`。

&nbsp;&nbsp;&nbsp;&nbsp;＜clinit＞（）方法对于类或接口来说并不是必需的，如果一个类中没有静态语句块，也没有对变量的赋值操作，那么编译器可以不为这个类生成＜clinit＞（）方法。

&nbsp;&nbsp;&nbsp;&nbsp;虚拟机会保证一个类的＜clinit＞（）方法在多线程环境中被正确地加锁、同步，如果多个线程同时去初始化一个类，那么只会有一个线程去执行这个类的＜clinit＞（）方法，其他线程都需要阻塞等待，直到活动线程执行＜clinit＞（）方法完毕。如果在一个类的＜clinit＞（）方法中有耗时很长的操作，就可能造成多个进程阻塞。

### 类加载器

> 虚拟机设计团队把类加载阶段中的“通过一个类的全限定名来获取描述此类的二进制字节流”这个动作放到Java虚拟机外部去实现，以便让应用程序自己决定如何去获取所需要的类。实现这个动作的代码模块称为“类加载器”。

&nbsp;&nbsp;&nbsp;&nbsp;**所有的类都由类加载器加载，加载的作用就是将 .class文件加载到内存。**

#### 1、类与类加载器
&nbsp;&nbsp;&nbsp;&nbsp;对于任意一个类，都需要由加载它的类加载器和这个类本身一同确立其在Java虚拟机中的**唯一性**，每一个类加载器，都拥有一个独立的类名称空间。
&nbsp;&nbsp;&nbsp;&nbsp;这句话可以表达得更通俗一些：比较两个类是否“相等”，只有在这两个类是由同一个类加载器加载的前提下才有意义，否则，即使这两个类来源于同一个Class文件，被同一个虚拟机加载，**只要加载它们的类加载器不同**，那这两个类就必定不相等。

+ 这里所指的“相等”，包括代表类的Class对象的equals（）方法、isAssignableFrom（）方法、isInstance（）方法的返回结果，也包括使用instanceof关键字做对象所属关系判定等情况。

#### 2、双亲委派模型

> 从Java虚拟机的角度来讲，只存在两种不同的类加载器：一种是启动类加载器（Bootstrap ClassLoader），这个类加载器使用C++语言实现，是虚拟机自身的一部分；另一种就是所有其他的类加载器，这些类加载器都由Java语言实现，独立于虚拟机外部，并且全都继承自抽象类java.lang.ClassLoader。

##### 2.1 JVM三种预定义类型类加载器
&nbsp;&nbsp;&nbsp;&nbsp; JVM 中内置了三个重要的 ClassLoader，除了 BootstrapClassLoader 其他类加载器均由 Java 实现且全部继承自java.lang.ClassLoader：

1. **BootstrapClassLoader**(启动类加载器) ：最顶层的加载类，由C++实现，负责加载 %JAVA_HOME%/lib目录下的jar包和类或者或被 -Xbootclasspath参数指定的路径中的所有类。启动类加载器无法被Java程序直接引用，用户在编写自定义类加载器时，如果需要把加载请求委派给引导类加载器，那么直接使用null代替即可。
2. **ExtensionClassLoader**(扩展类加载器) ：主要负责加载目录 %JRE_HOME%/lib/ext 目录下的jar包和类，或被 java.ext.dirs 系统变量所指定的路径下的jar包。开发者可以直接使用扩展类加载器。
3. **AppClassLoader**(应用程序类加载器) :面向我们用户的加载器，负责加载当前应用classpath下的所有jar包和类，开发者可以直接使用这个类加载器，如果应用程序中没有自定义过自己的类加载器，一般情况下默认为此加载器。

##### 2.2 双亲委派模型介绍

我们的应用程序都是由这3种类加载器互相配合进行加载的，如果有必要，还可以加入自己定义的类加载器。这些加载器之间的关系如下图所示：

![双亲委派模型.jpg](https://img.hacpai.com/file/2019/11/双亲委派模型-ce137836.jpg)


上图种所展示的类加载器之间的这种层次关系，称为类加载器的**双亲委派模型**（Parents Delegation Model）。

> 双亲委派模型要求除了顶层的启动类加载器外，其余的类加载器都应当有自己的父类加载器。这里类加载器之间的父子关系一般不会以继承的关系来实现，而是都是使用组合关系来复用父加载器的代码。

&nbsp;&nbsp;&nbsp;&nbsp;上图显示的并没有双亲呀？其实这个我觉得应该是翻译的问题，这里的双亲应该是指的父子代关系。一个加载器遇到了类啥也不干先问问他的上一代晓不晓得咋加载，依次递归，直到这个加载器的老祖宗（第一代即BootStrap），然后老祖宗再看看这东西（类）自己能加载了不，如果加载不了，再递归返回给自己的孩子，依次返回，直到遇到能加载这个类的祖宗或者自己（所有的祖宗都加载不了，只好自己干这事了，傲娇的加载器）。

##### 2.3 双亲委派模型工作过程

其实上面已经大概讲了下双亲委派的工作过程，下面给出书上的工作过程说明：

> 如果一个类加载器收到了类加载的请求，它首先不会自己去尝试加载这个类，而是把这个请求委派给父类加载器去完成，每一个层次的类加载器都是如此，因此所有的加载请求最终都应该传送到顶层的启动类加载器中，只有当父加载器反馈自己无法完成这个加载请求（它的搜索范围中没有找到所需的类）时，子加载器才会尝试自己去加载。

##### 2.4 双亲委派模型的好处

> 使用双亲委派模型来组织类加载器之间的关系，有一个显而易见的好处就是Java类随着它的类加载器一起具备了一种带有优先级的层次关系。例如类java.lang.Object，它存放在rt.jar之中，无论哪一个类加载器要加载这个类，最终都是委派给处于模型最顶端的启动类加载器进行加载，因此Object类在程序的各种类加载器环境中都是同一个类。相反，如果没有使用双亲委派模型，由各个类加载器自行去加载的话，如果用户自己编写了一个称为java.lang.Object的类，并放在程序的ClassPath中，那系统中将会出现多个不同的Object类，Java类型体系中最基础的行为也就无法保证，应用程序也将会变得一片混乱。

##### 2.5 双亲委派模型的实现

实现双亲委派的代码都集中在java.lang.ClassLoader 的loadClass()方法之中，如下所示：

```
private final ClassLoader parent; 
protected Class<?> loadClass(String name, boolean resolve)
        throws ClassNotFoundException
    {
        synchronized (getClassLoadingLock(name)) {
            // 首先，检查请求的类是否已经被加载过
            Class<?> c = findLoadedClass(name);
            if (c == null) {
                long t0 = System.nanoTime();
                try {
                    if (parent != null) {//父加载器不为空，调用父加载器loadClass()方法处理
                        c = parent.loadClass(name, false);
                    } else {//父加载器为空，使用启动类加载器 BootstrapClassLoader 加载
                        c = findBootstrapClassOrNull(name);
                    }
                } catch (ClassNotFoundException e) {
                   //抛出异常说明父类加载器无法完成加载请求
                }

                if (c == null) {
                    long t1 = System.nanoTime();
                    //自己尝试加载
                    c = findClass(name);

                    // this is the defining class loader; record the stats
                    sun.misc.PerfCounter.getParentDelegationTime().addTime(t1 - t0);
                    sun.misc.PerfCounter.getFindClassTime().addElapsedTimeFrom(t1);
                    sun.misc.PerfCounter.getFindClasses().increment();
                }
            }
            if (resolve) {
                resolveClass(c);
            }
            return c;
        }
    }
```

上述代码逻辑：
> 先检查是否已经被加载过，若没有则调用父加载器的loadClass()方法，若父加载器为空则默认使用启动类加载器作为父加载器。如果父类加载失败，则抛出ClassNotFoundException异常后，再调用自己的findClass()方法进行加载。

##### 2.6 破坏双亲委派模型

双亲委派模型并不是一个强制性的约束模型，而是Java设计者推荐给开发者的类加载实现方式。

为了避免使用双亲委派模型，我们可以自己定义一个类加载器，然后重写 loadClass() 即可。

&nbsp;&nbsp;&nbsp;&nbsp;在自定义ClassLoader的子类时候，我们常见的会有两种做法，一种是重写loadClass方法，另一种是重写findClass方法。其实这两种方法本质上差不多，毕竟loadClass也会调用findClass，但是从逻辑上讲我们最好不要直接修改loadClass的内部逻辑。我建议的做法是只在findClass里重写自定义类的加载方法。

&nbsp;&nbsp;&nbsp;&nbsp;loadClass这个方法是实现双亲委托模型逻辑的地方，擅自修改这个方法会导致模型被破坏，容易造成问题。因此我们最好是在双亲委托模型框架内进行小范围的改动，不破坏原有的稳定结构。同时，也避免了自己重写loadClass方法的过程中必须写双亲委托的重复代码，从代码的复用性来看，不直接修改这个方法始终是比较好的选择。

### 参考：
+ Java Guide：https://snailclimb.top/JavaGuide/#/?id=java
+ 《深入理解Java虚拟机》

