title: class 类文件结构与字节码指令
date: '2019-11-06 21:16:24'
updated: '2019-11-06 21:18:09'
tags: [Java, JVM]
permalink: /articles/2019/11/06/1573046182494.html
---
# JVM执行子系统

## 一、Class 类文件结构

### 1、Java跨平台的基础
> 各种不同平台的虚拟机与所有平台都统一使用的程序存储格式——字节码（ByteCode）是构成平台无关性的基石，也是语言无关性的基础。Java虚拟机不和包括Java在内的任何语言绑定，它只与“Class文件”这种特定的二进制文件格式所关联，Class文件中包含了Java虚拟机指令集和符号表以及若干其他辅助信息。

### 2、Class类的本质
&nbsp;&nbsp;&nbsp;&nbsp;任何一个Class文件都对应着唯一一个类或接口的定义信息，但反过来说，Class文件实际上它并不一定以磁盘文件的形式存在。
**Class文件是一组以8位字节为基础单位的二进制流**。
### 3、Class文件格式
&nbsp;&nbsp;&nbsp;&nbsp;各个数据项目严格按照顺序紧凑地排列在Class文件之中，中间没有添加任何分隔符，这使得整个Class文件中存储的内容几乎全部是程序运行的必要数据，**没有空隙存在**。
&nbsp;&nbsp;&nbsp;&nbsp;Class文件格式采用一种类似于C语言结构体的伪结构来存储数据，这种伪结构中只有两种数据类型：**无符号数**和**表**。
&nbsp;&nbsp;&nbsp;&nbsp;无符号数属于基本的数据类型，以u1、u2、u4、u8来分别代表1个字节、2个字节、4个字节和8个字节的无符号数，无符号数可以用来描述数字、索引引用、数量值或者按照UTF-8编码构成字符串值。
&nbsp;&nbsp;&nbsp;&nbsp;表是由多个无符号数或者其他表作为数据项构成的复合数据类型，所有表都习惯性地以“_info”结尾。表用于描述有层次关系的复合结构的数据，整个Class文件本质上就是一张表。

#### 3.1 Class File 结构
&nbsp;&nbsp;&nbsp;&nbsp;Class的结构不像XML等描述语言，由于它没有任何分隔符号，所以在其中的数据项，无论是**顺序**还是**数量**，都是被**严格限定**的，哪个字节代表什么含义，长度是多少，先后顺序如何，**都不允许改变**。
```
ClassFile {
    u4             magic; //Class 文件的标志
    u2             minor_version;//Class 的小版本号
    u2             major_version;//Class 的大版本号
    u2             constant_pool_count;//常量池的数量
    cp_info        constant_pool[constant_pool_count-1];//常量池
    u2             access_flags;//Class 的访问标记
    u2             this_class;//当前类
    u2             super_class;//父类
    u2             interfaces_count;//接口
    u2             interfaces[interfaces_count];//一个类可以实现多个接口
    u2             fields_count;//Class 文件的字段属性
    field_info     fields[fields_count];//一个类会可以有个字段
    u2             methods_count;//Class 文件的方法数量
    method_info    methods[methods_count];//一个类可以有个多个方法
    u2             attributes_count;//此类的属性表中的属性数
    attribute_info attributes[attributes_count];//属性表集合
}
```

Class文件字节码结构组织示意图 :

![class文件格式.jpg](https://img.hacpai.com/file/2019/11/class文件格式-e4cf6752.jpg)


![类文件字节码结构组织示意图.png](https://img.hacpai.com/file/2019/11/类文件字节码结构组织示意图-edef25db.png)


#### 3.2 魔数

> 每个 Class 文件的头四个字节称为魔数（Magic Number）,它的唯一作用是确定这个文件是否为一个能被虚拟机接收的 Class 文件。
#### 3.3 Class文件的版本

> 紧接着魔数的四个字节存储的是 Class 文件的版本号：第五和第六是次版本号，第七和第八是主版本号。

&nbsp;&nbsp;&nbsp;&nbsp;**向下兼容**：高版本的 Java 虚拟机可以执行低版本编译器生成的 Class 文件，但是低版本的 Java 虚拟机不能执行高版本编译器生成的 Class 文件。
#### 3.4 常量池

> 紧接着主次版本号之后的是常量池，常量池的数量是 constant_pool_count-1（常量池计数器是从1开始计数的，将第0项常量空出来是有特殊考虑的，索引值为0代表“不引用任何一个常量池项”）。

常量池主要存放两大常量：**字面量**和**符号引用**。
+ 字面量比较接近于 Java 语言层面的的常量概念，如文本字符串、声明为 final 的常量值等。
+ 符号引用则属于编译原理方面的概念,包括下面三类常量：
1. 类和接口的全限定名
2. 字段的名称和描述符
3. 方法的名称和描述符

&nbsp;&nbsp;&nbsp;&nbsp;常量池中每一项常量都是一个表，这14种表有一个共同的特点：开始的第一位是一个 u1 类型的标志位 -tag 来标识常量的类型，代表当前这个常量属于哪种常量类型．
#### 3.5 访问标志

> 用于识别一些类或者接口层次的访问信息，包括：这个Class是类还是接口；是否定义为public类型；是否定义为abstract类型；如果是类的话，是否被声明为final等
#### 3.6 类索引、 父类索引与接口索引集合

> 这三项数据来确定这个类的继承关系。
> &nbsp;&nbsp;&nbsp;&nbsp;类索引用于确定这个类的全限定名，父类索引用于确定这个类的父类的全限定名。由于Java语言不允许多重继承，所以父类索引只有一个，除了java.lang.Object之外，所有的Java类都有父类，因此除了java.lang.Object外，所有Java类的父类索引都不为0。
> &nbsp;&nbsp;&nbsp;&nbsp;接口索引集合就用来描述这个类实现了哪些接口，这些被实现的接口将按implements语句（如果这个类本身是一个接口，则应当是extends语句）后的接口顺序从左到右排列在接口索引集合中
#### 3.7 字段表集合
> 描述接口或者类中声明的变量。字段（field）包括类级变量以及实例级变量。

&nbsp;&nbsp;&nbsp;&nbsp;而字段叫什么名字、字段被定义为什么数据类型，这些都是无法固定的，只能引用常量池中的常量来描述。
&nbsp;&nbsp;&nbsp;&nbsp;字段表集合中不会列出从超类或者父接口中继承而来的字段，但有可能列出原本Java代码之中不存在的字段，譬如在内部类中为了保持对外部类的访问性，会自动添加指向外部类实例的字段。

#### 3.8 方法表集合
> 描述了方法的定义，但是方法里的Java代码，经过编译器编译成字节码指令后，存放在属性表集合中的方法属性表集合中一个名为“Code”的属性里面。

&nbsp;&nbsp;&nbsp;&nbsp;与字段表集合相类似的，如果父类方法在子类中没有被重写（Override），方法表集合中就不会出现来自父类的方法信息。但同样的，有可能会出现由编译器自动添加的方法，最典型的便是类构造器“＜clinit＞”方法和实例构造器“＜init＞”


#### 3.9 属性表集合

> 在 Class 文件，字段表，方法表中都可以携带自己的属性表集合，以用于描述某些场景专有的信息。与 Class 文件中其它的数据项目要求的顺序、长度和内容不同，属性表集合的限制稍微宽松一些，不再要求各个属性表具有严格的顺序，并且只要不与已有的属性名重复，任何人实现的编译器都可以向属性表中写 入自己定义的属性信息，Java 虚拟机运行时会忽略掉它不认识的属性。

#### 详解传送门：

+ https://snailclimb.top/JavaGuide/#/
+ https://blog.csdn.net/luanlouis/article/details/39960815
+ https://blog.csdn.net/tyyj90/article/details/78472986

### 字节码指令简介

> Java虚拟机的指令由一个字节长度的、代表着某种特定操作含义的数字（称为操作码，Opcode）以及跟随其后的零至多个代表此操作所需参数（称为操作数，Operands）而构成。

+ 由于限制了Java虚拟机操作码的长度为一个字节（即0～255），这意味着指令集的操作码总数不可能超过256条。
+ 大多数的指令都包含了其操作所对应的数据类型信息。例如：iload指令用于从局部变量表中加载int型的数据到操作数栈中，而fload指令加载的则是float类型的数据。
+ 大部分的指令都没有支持整数类型byte、char和short，甚至没有任何指令支持boolean类型。
+ 大多数对于boolean、byte、short和char类型数据的操作，实际上都是使用相应的int类型作为运算类型。

最基本的执行模型：
```
do{
	自动计算PC寄存器的值加1；
	根据PC寄存器的指示位置，从字节码流中取出操作码；
	if(字节码存在操作数)  从字节码流中取出操作数；
	执行操作码所定义的操作；
}while(字节码流长度 > 0)；
```

#### 1.加载和存储指令
&nbsp;&nbsp;&nbsp;&nbsp;用于将数据在栈帧中的局部变量表和操作数栈之间来回传输，这类指令包括如下内容:
+ 将一个局部变量加载到操作栈：iload、iload_＜n＞、lload、lload_＜n＞、fload、fload_＜n＞、dload、dload_＜n＞、aload、aload_＜n＞。
+ 将一个数值从操作数栈存储到局部变量表：istore、istore_＜n＞、lstore、lstore_＜n＞、fstore、fstore_＜n＞、dstore、dstore_＜n＞、astore、astore_＜n＞。
+ 将一个常量加载到操作数栈：bipush、sipush、ldc、ldc_w、ldc2_w、aconst_null、iconst_m1、iconst_＜i＞、lconst_＜l＞、fconst_＜f＞、dconst_＜d＞。
+ 扩充局部变量表的访问索引的指令：wide。

像iload_＜n＞这种带有尖括号的，其代表着一组指令，如iload_1、iload_2、iload_3。

#### 2.运算或算术指令

&nbsp;&nbsp;&nbsp;&nbsp;用于对两个操作数栈上的值进行某种特定运算，并把结果重新存入到操作栈顶。
+ 加法指令：iadd、ladd、fadd、dadd。
+ 减法指令：isub、lsub、fsub、dsub。
+ 乘法指令：imul、lmul、fmul、dmul...等

#### 3.类型转换指令

&nbsp;&nbsp;&nbsp;&nbsp;可以将两种不同的数值类型进行相互转换，这些转换操作一般用于实现用户代码中的显示类型转换操作，或者用来处理字节码指令集中数据类型相关指令无法与数据类型一一对应的问题。
Java虚拟机直接支持以下数值类型的宽化类型转换（即小范围类型向大范围类型的安全转换）：
+ int类型到long、float或者double类型。
+ long类型到float、double类型。
+ float类型到double类型。
处理窄化类型转换（Narrowing Numeric Conversions）时，必须显式地使用转换指令来完成，这些转换指令包括：i2b、i2c、i2s、l2i、f2i、f2l、d2i、d2l和d2f。
#### 4.对象创建与访问指令

+ 创建类实例的指令：new。
+ 创建数组的指令：newarray、anewarray、multianewarray。
+ 访问字段指令：getfield、putfield、getstatic、putstatic。
+ 检查类实例类型的指令：instanceof、checkcast。

#### 5.数组存取相关指令

+ 把一个数组元素加载到操作数栈的指令：baload、caload、saload、iaload、laload、faload、daload、aaload。
+ 将一个操作数栈的值存储到数组元素中的指令：bastore、castore、sastore、iastore、fastore、dastore、aastore。
+ 取数组长度的指令：arraylength。

#### 6.操作数栈管理指令

&nbsp;&nbsp;&nbsp;&nbsp;如同操作一个普通数据结构中的堆栈那样，Java虚拟机提供了一些用于直接操作操作数栈的指令，包括：
+ 将操作数栈的栈顶一个或两个元素出栈：pop、pop2。
+ 复制栈顶一个或两个数值并将复制值或双份的复制值重新压入栈顶：dup、dup2、dup_x1、dup2_x1、dup_x2、dup2_x2。
+ 将栈最顶端的两个数值互换：swap。

#### 7.控制转移指令

&nbsp;&nbsp;&nbsp;&nbsp;控制转移指令可以让Java虚拟机有条件或无条件地从指定的位置指令而不是控制转移指令的下一条指令继续执行程序，从概念模型上理解，可以认为控制转移指令就是在有条件或无条件地修改PC寄存器的值。控制转移指令如下。
+ 条件分支：ifeq、iflt、ifle、ifne、ifgt、ifge、ifnull、ifnonnull、if_icmpeq、if_icmpne、if_icmplt、if_icmpgt、if_icmple、if_icmpge、if_acmpeq和if_acmpne。
+ 复合条件分支：tableswitch、lookupswitch。
+ 无条件分支：goto、goto_w、jsr、jsr_w、ret。

#### 8.方法调用和返回指令

+ invokevirtual指令用于调用对象的实例方法，根据对象的实际类型进行分派（虚方法分派），这也是Java语言中最常见的方法分派方式。
+ invokeinterface指令用于调用接口方法，它会在运行时搜索一个实现了这个接口方法的对象，找出适合的方法进行调用。
+ invokespecial指令用于调用一些需要特殊处理的实例方法，包括实例初始化方法、私有方法和父类方法。
+ invokestatic指令用于调用类方法（static方法）。
+ invokedynamic指令用于在运行时动态解析出调用点限定符所引用的方法，并执行该方法，前面4条调用指令的分派逻辑都固化在Java虚拟机内部，而invokedynamic指令的分派逻辑是由用户所设定的引导方法决定的。
方法调用指令与数据类型无关。
+ 返回指令是根据返回值的类型区分的，包括ireturn（当返回值是boolean、byte、char、short和int类型时使用）、lreturn、freturn、dreturn和areturn，另外还有一条return指令供声明为void的方法、实例初始化方法以及类和接口的类初始化方法使用。

#### 9.异常处理指令

在Java程序中显式抛出异常的操作（throw语句）都由athrow指令来实现。

#### 10.同步指令

有monitorenter和monitorexit两条指令来支持synchronized关键字的语义。

#### 字节码详解传送门
+ https://blog.csdn.net/FU250/article/details/90267634
+ https://blog.csdn.net/FU250/article/details/80922162

#### 参考

+ Java Guide：https://snailclimb.top/JavaGuide/#/?id=java
+ 《深入理解Java虚拟机》

