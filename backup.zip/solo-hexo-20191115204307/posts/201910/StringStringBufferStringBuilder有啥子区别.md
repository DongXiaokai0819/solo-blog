title: String、String Buffer、String Builder有啥子区别？
date: '2019-10-07 16:26:53'
updated: '2019-10-07 16:26:53'
tags: [Java, 字符串]
permalink: /javasestring
---
### String、String Buffer、String Builder有啥子区别？
+ jdk 1.8

----
#### String
**String**类 是我们平时用的最多的一个类，它提供了构造和管理字符串的各种基本逻辑。
```
public final class String
    implements java.io.Serializable, Comparable<String>, CharSequence {
    /** The value is used for character storage. */
    private final char value[];
```
通过查看源码，String类被声明为 **final class** ，属性也为 **final** 的，所以String类是典型的 **Immutable** 类（即不可变类），也可理解为常量，所以String是线程安全的。
由于String类的不可变性，所有对字符串的裁剪、拼接操作都会产生 **新的String对象** ，然后将指针指向新的String对象。

#### AbstractStringBuilder
**String Buffer** 与 **String Builder** 都继承了 AbstractStringBuilder 。
```
abstract class AbstractStringBuilder implements Appendable, CharSequence {
    char[] value;
    int count;
    AbstractStringBuilder() {
    }
    AbstractStringBuilder(int capacity) {
        value = new char[capacity];
    }
```
通过查看AbstractStringBuilder 的源码可以看到，该类没有被声明为final，
所以**String Buffer** 与 **String Builder** 都是为了解决上述所说的拼接、裁剪产生的太多中间对象而提供的俩个类，我们可以用append或者add方法，把字符串添加到已有序列的末尾或者指定位置。
**String Buffer** 与 **String Builder**二者的方法是完全一样的，唯一的区别就是String Buffer中所有的方法都简单粗暴的被**synchronized**关键字修饰，而String Builder中没有，这也就造成了二者性能上的差异，所以说如果没有线程安全上的需要，还是用String Builder比较好。

#### 如何在三者之间选择？
1. 操作少量字符串，适用String
2. 单线程在字符串缓冲区下操作大量数据，适用String Builder
3. 多线程在字符串缓冲区下操作大量数据，适用String Buffer

> 总而言之，就是简单操作字符串的话用String就好，拼接字符串数据量大的话一般用StringBuilder，如果涉及多线程了，就用String Buffer

#### 格式化输出
##### System.out.format()
System.out.format() 模仿自c的printf()来进行格式化输出，如下所示
```
int x = 5;
double y = 5.222;
System.out.println("Row 1:" + x + y);
System.out.format("Row 1: %d , %f\n" , x , y);
System.out.printf("Row 1: %d , %f\n" , x , y);
```
format()与printf()是等价的。
##### String.format()
String.format() 以生成格式化的String对象，同上述 System.out.format()方法一样，但返回一个String对象。
` String sql = String.format("select * from %s where id in (%s) ",x,y)`
可以像这样拼接字符串，而不用非要用String Builder来一点一点的append。

以上内容参考自：
+ 极客时间 《Java核心技术36讲》
+ https://snailclimb.top/JavaGuide/#/?id=java
+ 《Java 编程思想》

由于jvm和并发编程还没学，一些东西还不懂，等过段时间再补充补充




